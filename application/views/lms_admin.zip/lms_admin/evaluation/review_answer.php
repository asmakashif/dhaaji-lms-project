<!-- Header Layout Content -->
<div class="mdk-header-layout__content">

    <div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
        <div class="mdk-drawer-layout__content page ">

            <div class="container-fluid page__container">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo base_url('admin_controller/admin_dashboard');?>">Home</a></li>
                    <li class="breadcrumb-item active">Assessments</li>
                </ol>
                <h1 class="h2">Review Answer Papers</h1>
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Test Sheet</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive border-bottom" data-toggle="lists" data-lists-values='["js-lists-values-employee-name"]'>
                            <table class="table mb-0">
                                <thead>
                                    <tr>
                                        <th style="width: 18px;">id</th>
                                        <th style="width: 100px;">Student Name</th>
                                        <th style="width: 50px;">Subject</th>
                                        <th style="width: 70px;">Download File</th>
                                        <th style="width: 50px;">Upload File</th>
                                    </tr>
                                </thead>
                                <tbody class="list" id="search">
                                    <?php $count=1;
                                    if(!empty($files)){ foreach($files as $frow){ ?>
                                        <tr>
                                            <td><?php echo $count++;?></td>
                                            <td><?php echo $frow['firstname']; ?></td>
                                            <td><?php echo $frow['subject']; ?></td>
                                            <td><a href="<?php echo base_url().'admin_controller/files/download/'.$frow['id']; ?>" class="btn btn-primary"><i class="fa fa-download"></i></a></td>
                                            <td>
                                                <a href="<?php echo base_url('admin_controller/files/edit_test_sheet/'.$frow['id']);?>" class="btn btn-info btn-xs"><i class="fa fa-upload"></i></a>
                                            </td>
                                        </tr>
                                    <?php } } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php $this->load->view('include1/sidebar')?>
        