<?php $this->load->view('include1/header'); ?>
<?php $this->load->view('include1/navbar'); ?>
<?php $this->load->view($main_content); ?>
<?php $this->load->view('include1/footer'); ?>